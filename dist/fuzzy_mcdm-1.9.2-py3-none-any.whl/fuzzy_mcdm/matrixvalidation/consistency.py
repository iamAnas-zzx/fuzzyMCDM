def const(a):
    return a