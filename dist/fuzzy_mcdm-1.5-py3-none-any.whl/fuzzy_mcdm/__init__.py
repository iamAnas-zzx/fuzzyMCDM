from _mathematics import factorial

def func1(a ,b):
    return a + b

# __all__ =["factorial" , "func1"]
# x = factorial(4)
# print(x)

__all__ =["func1" , "factorial"]