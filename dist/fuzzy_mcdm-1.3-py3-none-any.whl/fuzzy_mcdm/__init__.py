from _mathematics import factorial

def func1(a ,b):
    return a + b

__all__ =["factorial" , "func1"]
